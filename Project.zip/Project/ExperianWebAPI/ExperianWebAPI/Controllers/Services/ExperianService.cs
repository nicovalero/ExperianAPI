﻿using ExperianAPI.Model;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ExperianAPI.Controllers.Services
{
    enum ExperianServiceType
    {
        Album,
        Photo
    }
    public interface IExperianService
    {
        public Task<List<Photo>> GetPhotoInformation(string userId = "");
        public Task<List<Album>> GetAlbumInformation(string albumId = "");
    }

    public class ExperianService : IExperianService
    {
        private const string HOSTURL = "http://jsonplaceholder.typicode.com";
        private ICustomHttpClient _client;

        public ExperianService(ICustomHttpClient client)
        {
            _client = client;
        }

        /// <summary>
        /// Prepares the parameters and calls the method in charge of calling the external API.
        /// </summary>
        /// <param name="albumId"></param>
        /// <returns>
        /// A list of Photos.
        /// </returns>
        public async Task<List<Photo>> GetPhotoInformation(string albumId = "")
        {
            string parameters = (!string.IsNullOrEmpty(albumId) ? "?albumId=" + albumId : "");
            return await GetInformation<Photo>(ExperianServiceType.Photo, parameters);
        }

        /// <summary>
        /// Prepares the parameters and calls the method in charge of calling the external API.
        /// </summary>
        /// <param name="userId"></param>
        /// <returns>
        /// A list of Albums.
        /// </returns>
        public async Task<List<Album>> GetAlbumInformation(string userId = "")
        {
            string parameters = (!string.IsNullOrEmpty(userId) ? "?userId=" + userId : "");
            return await GetInformation<Album>(ExperianServiceType.Album, parameters);
        }

        /// <summary>
        /// Produces the Uri needed to call the external API, and calls it.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="type"></param>
        /// <param name="parameters"></param>
        /// <returns>
        /// A list of objects of any type.
        /// </returns>
        private async Task<List<T>> GetInformation<T>(ExperianServiceType type, string parameters)
        {
            List<T> response = new List<T>();
            string endpoint = HOSTURL;

            switch (type)
            {
                case ExperianServiceType.Album:
                    endpoint += "/albums";
                    break;
                case ExperianServiceType.Photo:
                    endpoint += "/photos";
                    break;
            }
            Uri uri = new Uri(endpoint + parameters);

            response = await _client.Get<List<T>>(uri);

            return response;
        }
    }
}
