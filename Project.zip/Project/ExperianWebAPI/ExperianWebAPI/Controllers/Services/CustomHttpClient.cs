﻿using Newtonsoft.Json;
using System;
using System.Net.Http;
using System.Threading.Tasks;

namespace ExperianAPI.Controllers.Services
{
    public interface ICustomHttpClient
    {
        public Task<T> Get<T>(Uri endpoint);
    }
    public class CustomHttpClient : ICustomHttpClient
    {
        private HttpClient _client;

        public CustomHttpClient()
        {
            _client = new HttpClient();
        }

        /// <summary>
        /// Calls an external API and deserializes the response into the given an instance of type T.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="endpoint"></param>
        /// <returns>
        /// An object of type T.
        /// </returns>
        public async Task<T> Get<T>(Uri endpoint)
        {
            var response = await _client.GetAsync(endpoint);

            if (response.StatusCode == System.Net.HttpStatusCode.OK)
            {
                T obj = JsonConvert.DeserializeObject<T>(await response.Content.ReadAsStringAsync());
                return obj;
            }

            return default;
        }
    }
}
