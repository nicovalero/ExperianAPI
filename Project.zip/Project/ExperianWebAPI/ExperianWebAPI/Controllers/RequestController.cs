﻿using ExperianAPI.Controllers.Services;
using ExperianAPI.Model;
using ExperianWebAPI.Class;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace ExperianWebAPI.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class RequestController : ControllerBase
    {
        private IExperianService _experianService;

        public RequestController(IExperianService service)
        {
            _experianService = service;
        }

        /// <summary>
        /// Will get every Album and Photo available in the API, combine them
        /// and return the information in a JSON format.
        /// </summary>
        /// <returns>
        /// A JSON serialized string with all the photo and album information retrieved.
        /// </returns>
        [HttpGet("GetAll")]
        public async Task<string> GetInformation()
        {
            List<Album> albums = await _experianService.GetAlbumInformation();
            List<Photo> photos = await _experianService.GetPhotoInformation();

            if (photos.Count > 0)
                albums = AlbumPhotoCombiner.Combine(albums, photos);

            return JsonConvert.SerializeObject(albums);
        }

        /// <summary>
        /// Will get every Album available in the API linked to an specified
        /// user. Then API will be called to retrieved their pictures,
        /// and return the information in a JSON format.
        /// </summary>
        /// <param name="userId"></param>
        /// <returns>
        /// A JSON serialized string with all the photo and album information retrieved.
        /// </returns>
        [HttpGet("GetAlbumsFromUser")]
        public async Task<string> GetInformationFromUser(int userId)
        {
            List<Album> albums = await _experianService.GetAlbumInformation(userId.ToString());

            if (albums.Count > 0)
            {
                List<Photo> photos = new List<Photo>();

                foreach (Album album in albums)
                {
                    List<Photo> photosResponse = await _experianService.GetPhotoInformation(album.Id.ToString());
                    if (photosResponse.Count > 0)
                        photos = photos.Concat(photosResponse)
                                       .ToList();
                }

                if(photos.Count > 0)
                    albums = AlbumPhotoCombiner.Combine(albums, photos);

                return JsonConvert.SerializeObject(albums);
            }
            return null;
        }
    }
}
