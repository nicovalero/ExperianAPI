﻿using Newtonsoft.Json;
using System.Collections.Generic;

namespace ExperianAPI.Model
{
    public class Album
    {
        [JsonProperty("userid")]
        public int UserId { get; private set; }

        [JsonProperty("id")]
        public int Id { get; private set; }

        [JsonProperty("title")]
        public string Title { get; private set; }

        public List<Photo> Photos { get; private set; }

        public Album()
        {
            Photos = new List<Photo>();
        }

        public Album(int userId, int id, string title, List<Photo> photos)
        {
            UserId = userId;
            Id = id;
            Title = title;
            Photos = photos;
        }
    }
}
