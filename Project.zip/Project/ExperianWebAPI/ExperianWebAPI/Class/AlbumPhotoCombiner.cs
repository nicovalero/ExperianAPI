﻿using ExperianAPI.Model;
using System.Collections.Generic;
using System.Linq;

namespace ExperianWebAPI.Class
{
    public static class AlbumPhotoCombiner
    {
        /// <summary>
        /// This method feeds the albums with the corresponding photos.
        /// The algorithm orders albums by Id, and photos by AlbumId, making the algorithm much easier to maintain.
        /// 
        /// The reason is: when a photo's AlbumId is above the current album's Id, we know we can discard the photo
        /// as there won't be an album matching such AlbumId.
        /// 
        /// By doing it this way, the time complexity becomes O(nlogn), being n the size of the biggest list between
        /// albums and photos.
        /// </summary>
        /// <param name="albums">Albums to pair with photos</param>
        /// <param name="photos">Photos to insert into albums</param>
        /// <returns></returns>
        public static List<Album> Combine(List<Album> albums, List<Photo> photos)
        {
            List<Album> orderedAlbums = albums.OrderBy(x => x.Id).ToList();
            Queue<Photo> photoQueue = new Queue<Photo>(photos.OrderBy(x => x.AlbumId).ToList());
            Photo currentPhoto;

            foreach (Album album in albums)
            {
                while (photoQueue.Count > 0)
                {
                    currentPhoto = photoQueue.Dequeue();
                    if (currentPhoto.AlbumId == album.Id)
                        album.Photos.Add(currentPhoto);
                    else if (currentPhoto.AlbumId > album.Id)
                        break;
                }
            }

            return orderedAlbums;
        }
    }
}
