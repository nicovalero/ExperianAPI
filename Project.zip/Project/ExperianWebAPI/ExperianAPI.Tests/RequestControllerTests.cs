using ExperianAPI.Controllers.Services;
using ExperianAPI.Model;
using ExperianWebAPI.Controllers;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ExperianAPI.Tests
{
    [TestClass]
    public class RequestControllerTests
    {
        private Mock<IExperianService> _experianServiceMock;
        private RequestController _testedClass;
        [TestInitialize]
        public void Setup()
        {
            _experianServiceMock = new Mock<IExperianService>();
            _testedClass = new RequestController(_experianServiceMock.Object);
        }

        [TestMethod]
        public void jsonIsNotNull_WHEN_userIdIsSpecified_AND_serviceIsSuccessful()
        {
            int userId = 1;
            int albumId = 1;
            List<Album> expectedAlbumList = new List<Album>();
            List<Album> mockAlbumList = new List<Album>();
            List<Photo> mockPhotoList = new List<Photo>();
            Album expectedFinalAlbum = new Album(albumId, userId, "any", new List<Photo>());
            Album mockAlbum = new Album(albumId,userId,"any", new List<Photo>());
            Photo mockPhoto = new Photo(albumId,1,"any","any","any");
            mockAlbumList.Add(mockAlbum);
            mockPhotoList.Add(mockPhoto);
            expectedFinalAlbum.Photos.Add(mockPhoto);
            expectedAlbumList.Add(expectedFinalAlbum);
            _experianServiceMock.Setup(x => x.GetAlbumInformation(userId.ToString())).Returns(Task.FromResult(mockAlbumList));
            _experianServiceMock.Setup(x => x.GetPhotoInformation(albumId.ToString())).Returns(Task.FromResult(mockPhotoList));
            string expectedJsonResult = JsonConvert.SerializeObject(expectedAlbumList);

            var actualResult = _testedClass.GetInformationFromUser(userId).Result;

            Assert.IsNotNull(actualResult);
            Assert.AreEqual(expectedJsonResult, actualResult);
        }

        [TestMethod]
        public void jsonIsNotNull_WHEN_userIdIsNotSpecified_AND_serviceIsSuccessful()
        {
            int albumId = 1;
            List<Album> expectedAlbumList = new List<Album>();
            List<Album> mockAlbumList = new List<Album>();
            List<Photo> mockPhotoList = new List<Photo>();
            Album expectedFinalAlbum = new Album(albumId, 1, "any", new List<Photo>());
            Album mockAlbum = new Album(albumId, 1, "any", new List<Photo>());
            Photo mockPhoto = new Photo(albumId, 1, "any", "any", "any");
            mockAlbumList.Add(mockAlbum);
            mockPhotoList.Add(mockPhoto);
            expectedFinalAlbum.Photos.Add(mockPhoto);
            expectedAlbumList.Add(expectedFinalAlbum);
            _experianServiceMock.Setup(x => x.GetAlbumInformation("")).Returns(Task.FromResult(mockAlbumList));
            _experianServiceMock.Setup(x => x.GetPhotoInformation("")).Returns(Task.FromResult(mockPhotoList));
            string expectedJsonResult = JsonConvert.SerializeObject(expectedAlbumList);

            var actualResult = _testedClass.GetInformation().Result;

            Assert.IsNotNull(actualResult);
            Assert.AreEqual(expectedJsonResult, actualResult);
        }

        [TestMethod]
        public void jsonIsNull_WHEN_userIdIsSpecified_AND_userIdDoesNotMatch()
        {
            int userId = 1;
            int albumId = 1;
            List<Album> mockAlbumList = new List<Album>();
            List<Photo> mockPhotoList = new List<Photo>();
            _experianServiceMock.Setup(x => x.GetAlbumInformation(userId.ToString())).Returns(Task.FromResult(mockAlbumList));
            _experianServiceMock.Setup(x => x.GetPhotoInformation(albumId.ToString())).Returns(Task.FromResult(mockPhotoList));

            var actualResult = _testedClass.GetInformationFromUser(userId).Result;

            Assert.IsNull(actualResult);
        }
    }
}
