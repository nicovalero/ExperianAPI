﻿using ExperianAPI.Model;
using ExperianWebAPI.Class;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections.Generic;

namespace ExperianAPI.Tests
{
    [TestClass]
    public class AlbumPhotoCombinerTests
    {
        [TestMethod]
        public void albumAndPhotosJoin_WHEN_albumIdMatches()
        {
            List<Album> expectedAlbumResult = new List<Album>();
            List<Album> testAlbums = new List<Album>();
            List<Photo> testPhotos = new List<Photo>();
            Album albumForExpectedResult = new Album(1,1,"any",new List<Photo>());
            Album testAlbum = new Album(1, 1, "any", new List<Photo>());
            Photo photo = new Photo(1, 1, "any","any","any");
            albumForExpectedResult.Photos.Add(photo);
            expectedAlbumResult.Add(albumForExpectedResult);
            testPhotos.Add(photo);
            testAlbums.Add(testAlbum);

            List<Album> actualAlbumResult = AlbumPhotoCombiner.Combine(testAlbums, testPhotos);

            Assert.AreEqual(actualAlbumResult.Count, expectedAlbumResult.Count);
            Assert.AreEqual(actualAlbumResult[0].Photos.Count, expectedAlbumResult[0].Photos.Count);
            Assert.AreEqual(actualAlbumResult[0].Id, expectedAlbumResult[0].Photos[0].AlbumId);
        }

        [TestMethod]
        public void albumAndPhotosDoNotJoin_WHEN_albumIdDoesNotMatch()
        {
            List<Album> expectedAlbumResult = new List<Album>();
            List<Album> testAlbums = new List<Album>();
            List<Photo> testPhotos = new List<Photo>();
            Album albumForExpectedResult = new Album(1, 1, "any", new List<Photo>());
            Album testAlbum = new Album(1, 1, "any", new List<Photo>());
            Photo photo = new Photo(2, 1, "any", "any", "any");
            albumForExpectedResult.Photos.Add(photo);
            expectedAlbumResult.Add(albumForExpectedResult);
            testPhotos.Add(photo);
            testAlbums.Add(testAlbum);

            List<Album> actualAlbumResult = AlbumPhotoCombiner.Combine(testAlbums, testPhotos);

            Assert.AreEqual(actualAlbumResult.Count, expectedAlbumResult.Count);
            Assert.AreEqual(actualAlbumResult[0].Photos.Count, 0);
        }
    }
}
