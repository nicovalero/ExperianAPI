﻿using ExperianAPI.Model;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Newtonsoft.Json;

namespace ExperianAPI.Tests
{
    [TestClass]
    public class AlbumsTests
    {
        [TestMethod]
        public void albumPropertiesAreFilled_WHEN_apiReturnsExpectedJsonObjects()
        {
            int userId = 1;
            int id = 1;
            string title = "any";
            int expectedUserId = 1;
            int expectedId = 1;
            string expectedTitle = "any";

            string jsonObject = "{\"userId\": " + userId + ",\"id\": " + id + ",\"title\": \"" + title + "\"}";
            Album actualAlbum = JsonConvert.DeserializeObject<Album>(jsonObject);

            Assert.AreEqual(expectedUserId, actualAlbum.UserId);
            Assert.AreEqual(expectedId, actualAlbum.Id);
            Assert.AreEqual(expectedTitle, actualAlbum.Title);
        }
    }
}
