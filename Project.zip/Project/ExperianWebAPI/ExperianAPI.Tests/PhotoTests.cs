﻿using ExperianAPI.Model;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Newtonsoft.Json;

namespace ExperianAPI.Tests
{
    [TestClass]
    public class PhotoTests
    {
        [TestMethod]
        public void albumPropertiesAreFilled_WHEN_apiReturnsExpectedJsonObjects()
        {
            int albumId = 1;
            int id = 1;
            string title = "any";
            string url = "any";
            string thumbnailUrl = "any";
            int expectedAlbumId = 1;
            int expectedId = 1;
            string expectedTitle = "any";
            string expectedUrl = "any";
            string expectedThumbnailUrl = "any";

            string jsonObject = "{\"albumId\": " + albumId + ",\"id\": " + id + ",\"title\": \"" + title + "\",\"url\": \"" + url + "\",\"thumbnailUrl\": \"" + thumbnailUrl + "\"}";
            Photo actualPhoto = JsonConvert.DeserializeObject<Photo>(jsonObject);

            Assert.AreEqual(expectedAlbumId, actualPhoto.AlbumId);
            Assert.AreEqual(expectedId, actualPhoto.Id);
            Assert.AreEqual(expectedTitle, actualPhoto.Title);
            Assert.AreEqual(expectedUrl, actualPhoto.Url);
            Assert.AreEqual(expectedThumbnailUrl, actualPhoto.ThumbnailUrl);
        }
    }
}
