using ExperianAPI.Controllers.Services;
using ExperianAPI.Model;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ExperianAPI.Tests
{
    [TestClass]
    public class ExperianServiceTests
    {
        private Mock<ICustomHttpClient> _clientMock;
        private ExperianService _testedClass;
        [TestInitialize]
        public void Setup()
        {
            _clientMock = new Mock<ICustomHttpClient>();
            _testedClass = new ExperianService(_clientMock.Object);
        }

        [TestMethod]
        public void albumListIsNotNull_WHEN_userIdIsNotSpecified_AND_clientIsSuccessful()
        {
            string userId = "";
            Uri uri = new Uri("http://jsonplaceholder.typicode.com/albums");
            List<Album> albumListMock = new List<Album>();
            _clientMock.Setup(x => x.Get<List<Album>>(uri)).Returns(Task.FromResult(albumListMock));

            List<Album> actualResult = _testedClass.GetAlbumInformation(userId).Result;

            Assert.IsNotNull(actualResult);
        }

        [TestMethod]
        public void albumListIsNull_WHEN_userIdIsNotSpecified_AND_clientReturnsNull()
        {
            string userId = "";
            Uri uri = null;
            List<Album> albumListMock = null;
            _clientMock.Setup(x => x.Get<List<Album>>(uri)).Returns(Task.FromResult(albumListMock));

            List<Album> actualResult = _testedClass.GetAlbumInformation(userId).Result;

            Assert.IsNull(actualResult);
        }

        [TestMethod]
        public void albumListIsNotNull_WHEN_userIdIsSpecified_AND_clientIsSuccessful()
        {
            string userId = "any";
            Uri uri = new Uri("http://jsonplaceholder.typicode.com/albums?userId=" + userId);
            List<Album> albumListMock = new List<Album>();
            _clientMock.Setup(x => x.Get<List<Album>>(uri)).Returns(Task.FromResult(albumListMock));

            List<Album> actualResult = _testedClass.GetAlbumInformation(userId).Result;

            Assert.IsNotNull(actualResult);
        }

        [TestMethod]
        public void albumListIsNull_WHEN_userIdIsSpecified_AND_clientReturnsNull()
        {
            string userId = "any";
            Uri uri = null;
            List<Album> albumListMock = null;
            _clientMock.Setup(x => x.Get<List<Album>>(uri)).Returns(Task.FromResult(albumListMock));

            List<Album> actualResult = _testedClass.GetAlbumInformation(userId).Result;

            Assert.IsNull(actualResult);
        }

        [TestMethod]
        public void photoListIsNotNull_WHEN_albumIdIsNotSpecified_AND_clientIsSuccessful()
        {
            string albumId = "";
            Uri uri = new Uri("http://jsonplaceholder.typicode.com/photos");
            List<Photo> photoListMock = new List<Photo>();
            _clientMock.Setup(x => x.Get<List<Photo>>(uri)).Returns(Task.FromResult(photoListMock));

            List<Photo> actualResult = _testedClass.GetPhotoInformation(albumId).Result;

            Assert.IsNotNull(actualResult);
        }

        [TestMethod]
        public void photoListIsNull_WHEN_userIdIsNotSpecified_AND_clientReturnsNull()
        {
            string albumId = "";
            Uri uri = null;
            List<Photo> photoListMock = new List<Photo>();
            _clientMock.Setup(x => x.Get<List<Photo>>(uri)).Returns(Task.FromResult(photoListMock));

            List<Photo> actualResult = _testedClass.GetPhotoInformation(albumId).Result;

            Assert.IsNull(actualResult);
        }

        [TestMethod]
        public void photoListIsNotNull_WHEN_albumIdIsSpecified_AND_clientIsSuccessful()
        {
            string albumId = "any";
            Uri uri = new Uri("http://jsonplaceholder.typicode.com/photos?albumId=" + albumId);
            List<Photo> photoListMock = new List<Photo>();
            _clientMock.Setup(x => x.Get<List<Photo>>(uri)).Returns(Task.FromResult(photoListMock));

            List<Photo> actualResult = _testedClass.GetPhotoInformation(albumId).Result;

            Assert.IsNotNull(actualResult);
        }

        [TestMethod]
        public void photoListIsNull_WHEN_userIdIsSpecified_AND_clientReturnsNull()
        {
            string albumId = "any";
            Uri uri = null;
            List<Photo> photoListMock = new List<Photo>();
            _clientMock.Setup(x => x.Get<List<Photo>>(uri)).Returns(Task.FromResult(photoListMock));

            List<Photo> actualResult = _testedClass.GetPhotoInformation(albumId).Result;

            Assert.IsNull(actualResult);
        }
    }
}
